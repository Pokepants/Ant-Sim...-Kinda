import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * This program simulates the life of an ant
 * 
 * Shaeel, Talha, Hamza
 * Version 2.0 2019/4/3
 */
public class AntArena extends World
{
    //memory refrences for everything
    Ant ant;
    BREADIT food;
    Spider spider;
    SimpleTimer fSpawnTimer = new SimpleTimer();
    AntArena antArena;
    SpiderWeb web;
    Colony swarm;
    LadyBug ladybug;
    LabelTwo label; 

    //int values that decide how many ants, spiders, etc. exist
    int numFood = 10;
    int numLadybug = 60;
    int numSpider = 3;
    int numColony = 2;
    int initNumWebs = 10;

    //creating the background sounds
    private GreenfootSound gameSound1= new GreenfootSound("C418 - Key - Minecraft Volume Alpha.wav");

    public AntArena()
    {
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1100, 600, 1); 
        //label to create text for the start screen
        label = new LabelTwo("Press o to go to The End. Press Right To Make Health Visible, Left To Do The Opposite.", 25);
        addObject(label, 550, 550); //adding the label object

        //the next for loops create everything that exists in ant arena(adds their objects)
        for (int i = 0; i < initNumWebs; i++){
            web = new SpiderWeb();
            addObject(web, Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        for (int i = 0; i < numLadybug; i++){
            ladybug = new LadyBug();
            addObject(ladybug,Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        for (int i = 0; i < numSpider; i++){
            spider = new Spider();
            addObject(spider, Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        for (int i = 0; i < numFood; i++){ 
            food = new BREADIT();
            addObject(food, Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
        }
        for (int i = 0; i < numColony; i++){
            swarm = new Colony();
            addObject(swarm,Greenfoot.getRandomNumber(getWidth()),Greenfoot.getRandomNumber(getHeight()));
        }
    }

    public void act(){

        gameSound1.playLoop(); //plays the game sounds

        //code used to spawn the bread to the ant arena
        if(fSpawnTimer.millisElapsed() > Food.spawnTime){
            //then spawn in another food
            BREADIT temp = new BREADIT();
            //adding object to the world
            addObject(temp,Greenfoot.getRandomNumber(getWidth()), Greenfoot.getRandomNumber(getHeight()));
            fSpawnTimer.mark();
        }

        //changes world to end screen
        if(Greenfoot.isKeyDown("o")){
            Greenfoot.setWorld(new EndScreen());
        }

        //toggle for the health bar
        if(Greenfoot.isKeyDown("right"))
        {
            HealthBar.visible = true;
        }
        else if(Greenfoot.isKeyDown("left"))
        {
            HealthBar.visible = false;
        }
    }
}