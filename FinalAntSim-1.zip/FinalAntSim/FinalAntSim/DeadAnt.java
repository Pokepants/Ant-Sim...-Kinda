import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


//turns the dead ants into a form of food
public class DeadAnt extends Food
{
        public Colony colony;
        public DeadAnt(Colony c){
            colony = c;
        }

}
