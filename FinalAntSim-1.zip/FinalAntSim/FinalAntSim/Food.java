import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public abstract class Food extends Actor
{
    //the stats for the food
    public static long spawnTime = 2000;
    private static double decayRate = 0.1;//lets try this to make the food lose energy over time
    private double energy = 100; 
    private double size = 30;
    private double weight = 10;
    public Colony colony;
    boolean carried = false;
    
    //memory refrence
    Ant ant;
    
    //moves food to carried state
    public void collected(boolean carry) {
        carried = carry;
    } 

    //sets the foods nrg
    public Food() {
        setEnergy();
    }

    //sets the foods nrg
    public Food(double e){
        setEnergy(energy);
    }
    

    public void act() 
    {  
        if(energy > 0){
            //make the energy decay
            removeEnergy(decayRate);
        }
        else{
            getWorld().removeObject(this);//when there is no more nrg dlete the food
        }
    }

    public void removeEnergy(double amount){
        //remove energy
        energy -= amount;
        //change the energy and weight based on the new energy
        setEnergy();
    }

    public void setEnergy(){
        size = 10 + energy*0.2;
        weight = 5 + energy*1;    

        if ((int)size > 0){
            getImage().scale((int)size,(int)size);
        }else{
            getWorld().removeObject(this);
        }
    }

    //sets nrg for the food
    public void setEnergy(double energy){
        this.energy = energy;
        setEnergy();
    }

    //if the food is not in use by any ant so an ant can take it to do smthn with it
    public boolean stillAvailable(){
        return getWorld() != null;
    }
}