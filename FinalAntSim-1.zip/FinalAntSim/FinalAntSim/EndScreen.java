import greenfoot.*; 
import java.awt.Color;

public class EndScreen extends World
{
    //memory refrences for everything
    TitleScreen titleScreen;
    Label label;
    Label how2;

    private GreenfootSound gameSound1= new GreenfootSound("C418 - Key - Minecraft Volume Alpha.wav");//creats background sound

    public EndScreen()
    {    
        super(1100, 600, 1);   //creates screen size  
        label = new Label("The End", 200); //creats lable for text
        how2 = new Label("Press p to go to the start screen", 50); //creates label for text
        //and the label objects to end screen
        addObject(label, 550, 100);
        addObject(how2, 550, 400);
    }

    public void act(){
        //changes world to the title screen
        if(Greenfoot.isKeyDown("p")){
            Greenfoot.setWorld(new TitleScreen());
        }

        gameSound1.playLoop();//plays the game sound
    }
}
