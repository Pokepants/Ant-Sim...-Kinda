import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//does nothing really other than be a place holder for other code that uses it
public class BREADIT extends Food
{
    
}
