import greenfoot.*; 
import java.awt.Color;

public class TitleScreen extends World
{
    //memory refrences for everything
    TitleScreen titleScreen;
    Label label;
    Label how2;
    Dance dance;

    private GreenfootSound gameSound1= new GreenfootSound("C418 - Key - Minecraft Volume Alpha.wav");//creats the sound

    public TitleScreen()
    {    
        super(1100, 600, 1); //screen size
        //creats the labels for text
        label = new Label("Ant Simulator", 200);
        how2 = new Label("Press i to start the simulator", 50);
        dance = new Dance(); //crates the dance gif
        //adds the label object to the world
        addObject(label, 550, 100);
        addObject(how2, 550, 400);
    }

    public void act(){
        //sets the worlds to the ant areana when teh key is pressed
        if(Greenfoot.isKeyDown("i")){
            Greenfoot.setWorld(new AntArena());
        }

        gameSound1.playLoop();//plays the game sound

        //plays the easter egg gif(animation) when "u" is pressed :)
        if(Greenfoot.isKeyDown("u")){
            addObject(dance, getWidth()/2, getHeight()/2);
        }
    }
}
