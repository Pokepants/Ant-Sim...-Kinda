public class statTracker  
{
    // instance variables
    private int aliveAnt;
    private int spawnedAnt;
    private int aliveSpider;
    private int enemyDef;
    private Colony colony;

    //all the info being created to be uded
    public statTracker(Colony c){
        colony =  c;
        aliveAnt = 0;
        spawnedAnt = 0;
        aliveSpider = 0;
    }

    //deacresed from the counter of how many ants are alive
    public void deadAnt(){
        aliveAnt--;
    }

    //increases the counter from how many ants are alive
    public void aliveAnt(){
        aliveAnt++;
        spawnedAnt();
    }

    //incerases enemy def
    public void enemyDef(){
        enemyDef++;
    }

    //decreses alive spider counter
    public void aliveSpider(){
        aliveSpider++;
    }
    
    //decreases alive spider counter
    public void deadSpider(){
        aliveSpider--;
    }

    //increases counter for how many ants are spawned
    private void spawnedAnt(){
        spawnedAnt++;
    }

    //returns enemy def
    public int cEnemyDef(){
        return enemyDef;
    }

    //returns amount of ants alive
    public int cAliveAnt(){
        return aliveAnt;
    }

    //returns how many ants are spawned
    public int cSpawnedAnt(){
        return spawnedAnt;
    }

    //returns amount of spider alive
    public int cAliveSpider(){
        return aliveSpider;
    }
    
}
