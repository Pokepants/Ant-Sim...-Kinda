import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
import java.lang.*;

/**
 * Write a description of class Colony here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Colony extends Actor{
    //states for the colony
    enum ColonyState{
        DEAD,SPAWN,IDLE
    }
    //memory refrences for everything
    public statTracker tracker;
    protected SimpleTimer fSpawnTimer;
    protected AntArena world;
    protected Ant ant; 
    protected ColonyState state = ColonyState.IDLE;
    protected HealthBar chb;

    //all the stats for the colony and how many ants it spawns
    protected double energy = 2000;
    protected double eThresh = 1000;
    double eMaxThresh = 2000;
    protected double spawncost = 100;
    protected double health = 10000;
    protected int numAnts = 10;
    List <Ant> ants = new ArrayList<Ant>();


    public void act(){
        //creates the timer and tracker for the colony
        if (fSpawnTimer == null){
            fSpawnTimer = new SimpleTimer();
        }
        if (tracker == null){
            tracker = new statTracker(this);
        } 
        if(world == null){
            world = (AntArena)getWorld();
        }
        //when the colony is idle and it has enough energy sets it to allow the colony to spawn ants
        if(state == ColonyState.IDLE){
            if (energy >= eThresh && tracker.cAliveAnt() <= numAnts){
                state = ColonyState.SPAWN;
            }
        }
        //when the colony spawns ants. When there is energy it will spawn the ants but if there is not enough energy it gets sert back to idle.
        else if (state == ColonyState.SPAWN){
            if (energy <= eThresh){
                state = ColonyState.IDLE;
            }
            if(energy >= eThresh && tracker.cAliveAnt() <= numAnts){
                if (tracker.cAliveAnt() >= numAnts){
                    state = ColonyState.IDLE;
                }
                if(fSpawnTimer.millisElapsed() >= Ant.spawnTime){
                    ant = new Ant(this, 10, 100, 100);
                    energy -= AbstAnt.sEnergy;
                    getWorld().addObject(ant, getX(), getY());
                    tracker.aliveAnt();
                    fSpawnTimer.mark();
                }
            }
        }
        //delets the colony when it no longer has  enough energy
        else if(state == ColonyState.DEAD){
            getWorld().removeObject(this);
        }
    }
    //allows the colony to gain energy
    public void gainFd(double gain){
        //gain energy from food
        energy += gain;
    }

}
