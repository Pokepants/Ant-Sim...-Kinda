import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


//turns dead lady bugs into food
public class DeadLadyBug extends Food
{
   
}
