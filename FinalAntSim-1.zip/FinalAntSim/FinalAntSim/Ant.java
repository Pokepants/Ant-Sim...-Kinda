import greenfoot.*; 
import java.util.*;

public class Ant extends AbstAnt
{

    protected double energyThreshold = 15;//energy thresh for the ants
    GreenfootImage leemon = new GreenfootImage("lemon.png");//creats the lemon image
    int powFood;//rng value for power food
    boolean foodie;//if the powFood can be created or not

    //memory refrences for everything
    AbstAnt target;
    Food snak;
    LadyBug extrafd;
    DeadAnt deadAnt;

    public static int spawnTime = 1000;//spawn tiem for the ants
    private static double decayRate = 0.1;//energy decay reate for teh ants

    //stats for the ants
    public Ant(Colony c, int a, int h, int e){  
        colony = c;
        attack = a;
        health = h;
        energy = e;
    }

    public void act() {
        //the rng function for teh food
        if(isTouching(Food.class) && foodie == true){
            powFood = Greenfoot.getRandomNumber(100);
            foodie = false;
        }
        //what happenes when the ant is idle
        if (state == AntState.IDLE){
            super.act();
            //if energy is below a threshhold value
            if(health < 100 && energy > energyThreshold){
                health++;
                energy -=5;
            }

            //if the snak does not exist
            if(snak == null){
                List<Food> cFoods = getObjectsInRange(sightRange, Food.class);
                snak = getSnak(cFoods);
            }
            //if the food does exist
            if(snak != null){
                //sets the ants to go collect the food for the colony
                if(colony.energy <= colony.eThresh ){
                    state = AntState.COLLECT;
                    return;
                }
                //if the energy is bellow the thrshe the ant will go eat food for itself
                else if(energy < energyThreshold){
                    //set to foraging
                    List<Food> prospects = getObjectsInRange(sightRange, Food.class);//list for all the food
                    if (prospects.size() > 0){
                        for (int i = 0; i < prospects.size(); i++){
                            snak = prospects.get(i);
                            if (snak.colony != this.colony){
                                state = AntState.FORAGE;
                                i = prospects.size();
                            }
                        }
                    }
                    state = AntState.FORAGE;//sate is set to foaging
                    return;
                }
                //looks for lady bug to go eat the lady bug as more food for the ant after looking for normal food
                else if(getObjectsInRange(sightRange,LadyBug.class).size()>0){
                    List<LadyBug> extrafds = getObjectsInRange(sightRange,LadyBug.class);
                    //set to foraging
                    int fdsize = extrafds.size();
                    extrafd = extrafds.get(0);
                    state = AntState.FORAGE;
                    return;
                }
            }
            //else if look for an ant to attack
            List<AbstAnt> targets = getObjectsInRange(sightRange, AbstAnt.class);
            if (targets.size()>0 && energy > energyThreshold){
                for (int i = 0; i < targets.size(); i++){
                    target = targets.get(i);
                    if (targets.get(i).colony != this.colony){
                        state = AntState.ATTACK;
                        i = targets.size();
                    }
                }
            }
        }
        //what happenes when the state is set to attack
        else if (state == AntState.ATTACK) {
            //what happens when the target does not exist
            if (target.getWorld() == null){
                target = null;
                state = AntState.IDLE;
            }
            //sets state to ide if the energy is too low
            else if (energy < energyThreshold && getObjectsInRange(sightRange, Food.class).size()>0 && snak!=null){
                state = AntState.IDLE;
            }
            //what happenes when 2 ants touch and fight
            else if (isTouching(AbstAnt.class) && getOneIntersectingObject(AbstAnt.class) == target){
                //calculate the damage done in the attack
                double damage = Greenfoot.getRandomNumber(attack);
                //call the target's takeDamage method
                target.takeDamage(damage);
                if (target.getHealth()> 0){
                    colony.tracker.enemyDef();
                    //System.out.println(colony.tracker.cEnemyDef());
                }
                energy -= (damage*0.1);
                hb.update();
            }
            else{
                //turn towards the ant ==> turntowards
                turnTowards(target.getX(),target.getY());
                //move the ant
                move(speed);  
            }
        }
        else if (state == AntState.COLLECT) {
            //make sure that colony is still below energy threshold
            if (colony.energy >= colony.eMaxThresh){
                //after Colony is full, go back to idle state
                snak.carried = false;
                state = AntState.IDLE;
            }
            //if the food no longer exists sets the state back to idle
            else if(snak.getWorld() == null){
                snak.carried = false;
                snak = null;
                state = AntState.IDLE;
                return;
            }
            //find all nearby food (only bread) that can be collected
            if (intersects(snak)){
                //bring it to the Colony
                System.out.println(snak);
                snak.setLocation(this.getX(),this.getY());
                //move the ant towards the Colony
                turnTowards(colony.getX(),colony.getY());
                move(speed);
                hb.update();
                //when the ant touches the colont after getting the food it takes the following actions
                if (intersects(colony)){
                    snak.carried = false;
                    getWorld().removeObject(snak);
                    snak = null;
                    colony.gainFd(cEnergy);
                    state = AntState.IDLE;
                    return;
                }
            }
            //tell this ant to move to it
            else {
                turnTowards(snak.getX(),snak.getY());
                //move the ant
                move(speed);
                hb.update();
            }
        }
        //when the ant is getting food for itself
        else if (state == AntState.FORAGE){
            //when the food actually exists for it to eat and is not being collected by any other ant
            if (snak != null && getObjectsInRange(100,BREADIT.class).size()>0){
                foodie = true;//lets the rng take place for the powerup food
                //what happens when the food doesnt exist
                if (snak.getWorld() == null){
                    snak = null;
                    state = AntState.IDLE;
                }
                //if the energy is too low the ant is set back to idle
                else if (energy <= 100){
                    state = AntState.IDLE;   
                }
                //when the ant is not toucking the food it goes towards the food
                else if(!isTouching(Food.class)){
                    turnTowards(snak.getX(),snak.getY());
                    //move the ant
                    move(speed);
                    hb.update();
                }
                //when the ant is touching the food it eats it and takes nrg from it and make it is own the try catch is to prevent errors for the power up food
                else if (isTouching(Food.class)){
                    //Greenfoot.playSound("973571551897414.wav");
                    double damage = Greenfoot.getRandomNumber(attack);
                    try{
                        snak.removeEnergy(damage);
                    }
                    catch(Exception e){
                        return;
                    }
                    energy += damage;
                }
                //the lady bugs as food 
            }else if (extrafd != null){
                //when the lady bugs as food do not exist
                if (extrafd.getWorld() == null){
                    extrafd = null;
                    state = AntState.IDLE;
                }
                //if the ants energy is too low it gets set to idle
                else if (energy <= 100){
                    state = AntState.IDLE;   
                }
                //when the ant is touching the lady bug
                else if (isTouching(LadyBug.class)){
                    double gain = 10;
                    double damage = Greenfoot.getRandomNumber(attack);
                    extrafd.takeDamage(attack*2);
                    energy += damage;
                }
                //goes towards the lady bug if it is not touching it
                else{
                    //turn towards the ant ==> turntowards
                    turnTowards(extrafd.getX(),extrafd.getY());
                    //move the ant
                    move(speed);
                }
            }
            //the power up food code, if the number is the right nubmber it will buff the ants attack and make the food look like a lemon, try catch exists to set the ant back to idle when weird edge case errors happen
            try{
                if(Greenfoot.getRandomNumber(10)==1){
                    if(intersects(snak)){
                        attack = 21;
                        System.out.println(snak);
                        System.out.println(leemon);
                        snak.setImage(leemon);
                    }
                }
            }
            catch(Exception e){
                state = AntState.IDLE;
            }
        }
        //what happens when the ant is dead
        else if (state == AntState.DEAD){
            deadAnt = new DeadAnt(colony);
            getWorld().addObject(deadAnt, getX(), getY());
            getWorld().removeObject(this);
            colony.tracker.deadAnt();
        }
    } 

    //the code which makes the ant move
    public void move(int distance){
        energy -= 1 ;  //decreases energy when the ant moves
        super.move(distance);
        //what happens when the energy is below 0
        if (energy <=0){
            health--;
            energy = 0;
        }
        //what happenes when energy is bellow 0
        if (health <= 0){
            List <BREADIT> snaks = getObjectsInRange(sightRange,BREADIT.class);
            for(int i = 0; i < snaks.size(); i++){
                if(intersects(snaks.get(i))){
                    snaks.get(i).carried = false;
                }
            }
            //change it to dead
            state = AntState.DEAD;
        }
    }

    //allows the food to be carried by the ant
    protected Food getSnak(List <Food> items){
        for(Food item : items){
            if (item.carried == false){
                item.carried = true;
                return item;
            }
        }
        return null;
    }

    //gets the distance between the food and the ants.
    public double findDistanceBetween(Food a1, LadyBug a2){
        return Math.sqrt(Math.pow(a1.getX() - a2.getX(), 2) + Math.pow(a1.getY() - a2.getY(), 2));
    }

}