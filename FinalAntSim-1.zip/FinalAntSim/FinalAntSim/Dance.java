import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Dance extends Actor
{
    GifImage[] gifImages = new GifImage[85];//sets how many images there are in the gif
    int imageNumber = 1;//what image to start on
    
    //sorts throught the images for the gif to work and then sets that image4
    public Dance()
    {
        for(int i=1;i < gifImages.length;i++){
            gifImages[i] = new GifImage("f (" + i + ").gif");
            setImage(gifImages[imageNumber].getCurrentImage());
        }
    }
    
    //calls the animation for the gif to move
    public void act() 
    {
        animation();
    }    
    
    //runs the gif
    public void animation()
    {
        imageNumber = ( imageNumber + 1 ) % gifImages.length;
        if(imageNumber == 0){
            imageNumber = 1;
        }
        setImage(gifImages[imageNumber].getCurrentImage());
    }
}
