import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;


public class SpiderWeb extends Actor
{
    //memory refrences
    Ant prey;
    Spider trapper;
    SpiderWeb web;
    //the stats for the spider webs
    private double size = 30;
    public static long spawnTime = 2000;
    

    public void act() 
    {
        List<Ant> preys = getObjectsInRange(20,Ant.class);//list of the ants
        
        //when the ant is touching the spider web its speed gets set to 0(it doesnt move)
        if(preys.size()>0){
            if (isTouching(Ant.class)){
                int stuck = 0;
                for(int i = 0; i < preys.size(); i++){
                    preys.get(i).speed = stuck;
                }
            }
        }
    }    
}
