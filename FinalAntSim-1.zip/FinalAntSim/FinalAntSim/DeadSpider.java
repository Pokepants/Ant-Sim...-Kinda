import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

//turns spiders into food
public class DeadSpider extends Food
{

}
