import greenfoot.*;
import java.util.*;

public class LadyBug extends AbstAnt
{
    //variables that controls the stats of the ladybug
    double health = 100;
    double energy = 100;
    AntState state = AntState.IDLE;

    //memory refrence
    Food food;

    public void act() 
    {
        //when it is idle it just moves randomly
        if (state == AntState.IDLE){
            super.act();
            turn(Greenfoot.getRandomNumber(60)-30);
            move(Greenfoot.getRandomNumber(5)-2);

        }
        //remove it from the world when dead
        else if(state == AntState.DEAD){
            getWorld().removeObject(this);
        }
    }
    //lets the ladybug take dmg
    public void takeDamage(double damage) {
        //removes the damage from the health
        health -= damage;
        //if all the health is gone
        if (health <= 0){
            //change it to dead
            state = AntState.DEAD;
        } 
    }

    public double findDistanceBetween(Food a1, LadyBug a2){
        return Math.sqrt(Math.pow(a1.getX() - a2.getX(), 2) + Math.pow(a1.getY() - a2.getY(), 2));
    }
}
